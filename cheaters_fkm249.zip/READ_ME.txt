HOW TO COMPILE THIS PROGRAM:
The makefile for this program is "makefile". Call it using "make -f makefile" (no quotations). The files included in this zipped file are "main.cpp", our driver program, and "Queue.h", a header file that includes all helper functions and global variables. 

HOW TO RUN THIS PROGRAM:
Type "./plagiarismCatcher name_of_folder_of_files number_of_words_in_sequences number_of_collisions_to_find" into the command line.
