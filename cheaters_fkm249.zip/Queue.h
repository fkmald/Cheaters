#include <vector>
#include <fstream>
#include <iostream>
#include <cstdlib>
#include <stdio.h>
#include <ctype.h>
#include <math.h>
using namespace std;

#ifndef CHEATERS_QUEU_H
#define CHEATERS_QUEU_H
int MAX = 50000;
struct ChunkNode
{
    int i;
    ChunkNode *next;
};

ChunkNode *headChunk;  //the head pointer
ChunkNode *tailChunk;

//Given a vector of words (strings), this function returns a string of all the alphanumberic letters in the word in lowercase form. 
string Chunking(vector<string> chunk, int n, int place){
    string newChunk;
    string word;
    for (int i=place; i<(place+n); i++){ // going through vector
        word = chunk.at(i);
        int length = word.length();
        for (int j = 0; j< length; j++){
            if (isalnum(word[j]))
                newChunk += tolower(word[j]);
        }
    }

    return newChunk;
}

//This is a hash function. Given a string, it returns a key (an integer) to access the hash table with.
unsigned int Hashing (const string & chunk){
    unsigned int result = 0;
    for (int i = 0; i < chunk.size(); i++){
        result += chunk[i] * (pow(7,i%11));		//11 and 7 are used because they are prime numbers.
    }
    result = result % MAX;				//we mod by MAX to keep the key in range of the hash table.
    return result;
}

//This function initializes our hash table (which is an array of ChunkNode pointers) to NULL pointers.
void InitHashTable (ChunkNode* HashTable[]){
    for ( int j = 0; j < MAX; j++)
        HashTable[j] = NULL;
}

//This function places a chunk's file index into the hash table based on the key that is passed in.
//The collisions are stored using a linked list.
void placeInHashTable (int result, int index, ChunkNode* table[]){
    bool flag = false;
    if(table[result] != NULL){		//if a file is already stored there and there IS a collision:
        ChunkNode *temp = table[result];
        while(temp->next != NULL){
            if(temp->i == index){	//collisions from the same file should not be stored in the linked list.
                flag = true;
                temp->next = NULL;

            }
            else{
                temp = temp->next;
            }
        }
    }
    if(!flag) { //if the index of the file isn't already there:
        ChunkNode *slot = new ChunkNode();
        ChunkNode *temp = table[result];
        slot->i = index;
        slot->next = temp;
        table[result] = slot;
    }
}

#endif 
